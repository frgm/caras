# VideoFaceDetection #

This code has been moved to [https://github.com/bytefish/VideoFaceDetection](https://github.com/bytefish/VideoFaceDetection).