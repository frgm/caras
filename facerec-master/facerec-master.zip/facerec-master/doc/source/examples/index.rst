.. _examples_index:

========
Examples
========

.. toctree::
   :maxdepth: 2

   quickstart
   videofacerec